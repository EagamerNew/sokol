    
<?php

//database_connection.php $connect = new PDO("mysql:host=srv-pleskdb41.ps.kz:3306;dbname=digita30_socol", "digit_sokoluser", "In017em?");

$connect = new PDO("mysql:host=localhost:3306;dbname=digita30_socol", "root", "");



?>